# Analytical-Layer Revision Summary v1.0

## Verified allocation

- Reuse: 19 requirements
- Extension: 19 requirements
- New construction: 16 requirements
- Series-pending validation: 12 requirements

## Governing change

The prior plan grouped work by subject area but treated every area as though it required a new analytical layer. The revised plan first asks whether the capability already exists, needs extension, is genuinely absent, or cannot yet be validated without another book.

## Practical effect

- Nineteen working capabilities are preserved and regression-tested.
- Nineteen capabilities extend existing evidence-bearing structures.
- Sixteen capabilities require new bounded construction.
- Twelve cross-book capabilities remain pending until a second manuscript is loaded.
- No new extraction begins until Gate 0 approval.
