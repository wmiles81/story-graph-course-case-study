# Coverage Verification Report v1.0

**Date:** 2026-07-23  
**Scope:** 66 requirements from the expanded Book and Series inventory  
**Evidence basis:** actual frozen Act II CSV schemas and records, plus Act III operational, dependency, query, evaluation, and safe-failure artifacts

## Result

- VERIFIED FULL: 19
- VERIFIED PARTIAL: 19
- VERIFIED ABSENT: 16
- SERIES PENDING: 12
- Total: 66

## Important correction to the preliminary audit

The first audit used three broad labels and treated many series requirements as absent. The verified audit introduces **SERIES_PENDING** because a single-book corpus cannot prove or disprove cross-book continuity support. That is not semantic hair-splitting; it prevents us from declaring a failure before the required evidence exists.

## Schema findings

### Strong existing foundations

- Assertion-level provenance and authority are fully represented.
- Proposition and assertion are structurally separate.
- Scene identity and source boundaries are stable across 153 scenes.
- Character epistemic state has validity ranges, reveal scenes, viewpoint context, evidence, and authority.
- Custody and promise lifecycles are dedicated populated layers.
- Promise statuses already distinguish partial, substantial, final, failed/reopened, and deferred closure.
- Continuity findings are adjudicated rather than merely detected.
- Revision impact uses 3,228 dependency edges and includes repaired lexical dependencies.
- Gold evaluation and negative/safe-failure testing are real, not aspirational checkboxes wearing a tie.

### Partial rather than absent

Several capabilities originally labeled absent have genuine footholds:

- reader knowledge exists in `reader_context`, reader-knowledge assertions, and the Chapter 1–3 reader-context pilot;
- event information exists in scene `major_events_candidate` and event assertion types, but lacks stable event identity;
- world rules can be expressed as propositions/assertions, but no rule-specific registry or exception lifecycle exists;
- character and relationship states exist, but are sparse analytical records rather than comprehensive transition histories;
- causality has `derived_from` and dependency edges, but dependency must not be mistaken for causal proof;
- location and custody fields support limited spatial reasoning, but not topology or blocking.

### Confirmed missing layers

The inspected schemas do not contain dedicated support for:

- plot-thread registry, many-to-many membership, contribution, or intersections;
- enabling conditions and perceived-versus-actual causality;
- narrative irreversibility and reversal cost;
- entrances, exits, blocking, posture, orientation, and reachability;
- scene state-change, missing-bridge, redundancy, or subplot-contribution audits;
- graph centrality or community-detection results.

## Classification changes from the preliminary audit

- `REQ-005` Stable identity across books: **PARTIAL → SERIES_PENDING**
- `REQ-011` Cross-book inherited knowledge: **ABSENT → SERIES_PENDING**
- `REQ-012` Reader knowledge timeline: **ABSENT → PARTIAL**
- `REQ-013` Dramatic irony windows: **ABSENT → PARTIAL**
- `REQ-015` Series chronology: **ABSENT → SERIES_PENDING**
- `REQ-017` Recurring-object history across books: **ABSENT → SERIES_PENDING**
- `REQ-019` Partial payoff versus final closure: **PARTIAL → FULL**
- `REQ-020` Cross-book promise lifecycle: **ABSENT → SERIES_PENDING**
- `REQ-030` Explicit world-rule registry: **ABSENT → PARTIAL**
- `REQ-031` Inferred rule with confidence and evidence: **ABSENT → PARTIAL**
- `REQ-032` Character belief about a rule: **ABSENT → PARTIAL**
- `REQ-033` Exception, violation, and clarification: **ABSENT → PARTIAL**
- `REQ-043` Setup without payoff: **PARTIAL → FULL**
- `REQ-049` Cross-book contradiction detection: **ABSENT → SERIES_PENDING**
- `REQ-050` Retcon and clarification ledger: **ABSENT → SERIES_PENDING**
- `REQ-052` Book-boundary spoiler scope: **ABSENT → SERIES_PENDING**
- `REQ-054` Semantic and lexical dependency detection: **PARTIAL → FULL**
- `REQ-055` Cross-book revision impact: **ABSENT → SERIES_PENDING**
- `REQ-058` Adversarial and negative tests: **PARTIAL → FULL**
- `REQ-061` Human-oriented narrative views: **PARTIAL → FULL**
- `REQ-064` Long-form character arc: **ABSENT → SERIES_PENDING**
- `REQ-065` Long-form relationship arc: **ABSENT → SERIES_PENDING**
- `REQ-066` Cross-book plot-thread registry: **ABSENT → SERIES_PENDING**

## Gate decision

**Gate 0 is not yet ready for approval.** The coverage classifications are now verified, but the next step is to revise the proposed analytical-layer plan so that it:

1. reuses the full layers without rebuilding them;
2. extends partial layers from their actual columns;
3. creates only the confirmed missing layers;
4. reserves series-pending requirements for the first additional book ingestion.

No new manuscript extraction has begun.
