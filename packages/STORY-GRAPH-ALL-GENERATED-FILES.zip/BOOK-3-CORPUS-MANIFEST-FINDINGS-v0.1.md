# BOOK 3 CORPUS MANIFEST FINDINGS v0.1

**Files classified:** 56

## Inclusion summary

- **exclude:** 3
- **exclude-initial:** 45
- **include-candidate:** 2
- **include-primary:** 4
- **include-secondary:** 2

## Source-class summary

- **analytical-document:** 5
- **canonical-bible:** 2
- **chapter-draft:** 30
- **development-reference:** 4
- **editing-material:** 2
- **ideation-document:** 2
- **manuscript:** 4
- **other:** 2
- **structural-plan:** 2
- **system-artifact:** 2
- **utility-or-data:** 1

## Manuscript candidates

- `series/books/book-3/phase-7-drafting/full-manuscript-v1.md` — 186,003 bytes, version `v1`, SHA-256 `b25bc3d040211c05…`, pilot status **exclude-initial**
- `series/books/book-3/phase-7-drafting/full-manuscript-v2.md` — 450,377 bytes, version `v2`, SHA-256 `6f95530eb1139e21…`, pilot status **exclude-initial**
- `series/books/book-3/phase-7-drafting/full-manuscript-v3.md` — 448,135 bytes, version `v3`, SHA-256 `3260b4007c890fc8…`, pilot status **include-candidate**
- `series/books/book-3/phase-8-editing/MANUSCRIPT.md` — 450,520 bytes, version `unlabeled`, SHA-256 `006b9a0e27899bce…`, pilot status **include-candidate**

## Exact-content comparison

- No full-manuscript candidates are byte-for-byte identical.

## Provisional finding

`full-manuscript-v3.md` and `phase-8-editing/MANUSCRIPT.md` remain competing authoritative candidates until a textual diff and surrounding editorial evidence establish which is later and intended as current canon.

The manifest deliberately preserves both. Filenames are evidence, not divine revelation.