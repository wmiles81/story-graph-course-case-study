# BOOK 3 MANUSCRIPT AUTHORITY ASSESSMENT v0.1

**Purpose:** Determine the provisional authoritative Book 3 manuscript for the story-graph pilot.

## Candidate statistics

| Candidate | Words | Chapters detected | Lines | SHA-256 prefix |
|---|---:|---:|---:|---|
| `full-manuscript-v1` | 31,202 | 14 | 3,989 | `6e572a39d4502dc0…` |
| `full-manuscript-v2` | 75,223 | 30 | 10,680 | `f81c312112b87e61…` |
| `full-manuscript-v3` | 74,903 | 30 | 10,695 | `503e0a63d1013646…` |
| `phase-8-manuscript` | 75,214 | 30 | 10,723 | `6843f6bc8168e4e7…` |

## Version comparison

| From | To | Similarity | Word delta | Added lines | Deleted lines | Replaced extent |
|---|---|---:|---:|---:|---:|---:|
| `full-manuscript-v1` | `full-manuscript-v2` | 0.4668 | +44,021 | 41 | 159 | 7245 |
| `full-manuscript-v2` | `full-manuscript-v3` | 0.9292 | -320 | 0 | 5 | 764 |
| `full-manuscript-v3` | `phase-8-manuscript` | 0.9231 | +311 | 42 | 1 | 816 |

## v3 versus Phase 8

- Textually distinct: **yes**
- Overall line similarity: **0.9231**
- Word-count change: **+311**
- Chapter rows modified: **30**
- Chapter rows unchanged: **0**
- Chapter rows added: **0**
- Chapter rows removed: **0**

## Provisional authority decision

**Use `phase-8-editing/MANUSCRIPT.md` as the provisional authoritative manuscript for the pilot.**

Rationale:

1. It occupies the later editorial phase.
2. It is textually distinct from `full-manuscript-v3.md`.
3. `full-manuscript-v3.md` is best treated as its immediate predecessor.
4. The Phase 8 manuscript should be marked `current-candidate`, not `author-verified`, until explicit author confirmation exists.

## Graph treatment

- Phase 8 manuscript: authority level 4, status `current-candidate`.
- v3 manuscript: authority level 3, status `superseded-candidate`.
- v1 and v2 manuscripts: historical revision contexts.
- Assertions from earlier versions must never leak into current canon without explicit persistence evidence.

## Produced files

- `BOOK-3-MANUSCRIPT-CHAPTER-DIFF-v0.1.csv`
- `full-manuscript-v1_TO_full-manuscript-v2.diff`
- `full-manuscript-v2_TO_full-manuscript-v3.diff`
- `full-manuscript-v3_TO_phase-8-manuscript.diff`