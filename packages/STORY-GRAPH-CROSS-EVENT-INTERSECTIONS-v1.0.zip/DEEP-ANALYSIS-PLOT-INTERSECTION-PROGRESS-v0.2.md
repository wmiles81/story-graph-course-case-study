# Progress v0.2

- Direct multi-thread intersections: 17
- Cross-event intersections: 14
- Next: causal dependency and narrative irreversibility design.
